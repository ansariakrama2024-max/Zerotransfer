# ZeroRh Transfer (Android)

A local-network file transfer app prototype. The Android phone hosts a browser-based transfer page; the laptop only needs a browser and must be connected to the phone hotspot/shared Wi-Fi.

## Build APK with GitHub Actions
1. Upload this project folder's contents to a GitHub repository (the `.github/workflows/deploy.yml` file must be included).
2. Open the repository's **Actions** tab.
3. Select **Build ZeroRh Transfer APK** and click **Run workflow** (or push to `main`).
4. Open the completed workflow run, scroll to **Artifacts**, and download `ZeroRh-Transfer-APK`.
5. Extract the ZIP artifact and install `app-debug.apk` on your Android phone. Android may ask you to allow installation from the browser/files app.

## Use
1. Enable your phone hotspot and connect your laptop to it.
2. Open the app and tap **START TRANSFER SERVER**.
3. Enter the displayed URL in the laptop browser.
4. Enter the six-digit PIN displayed on the phone.
5. Upload files from the laptop to the phone, or download files already listed on the phone.

Received files are saved in the app's private external `Received` folder. They can be accessed from the app's storage area using a file manager. Keep the app open during transfers.

## Security / limitations
- This prototype uses HTTP on the local network (not encrypted). Use only on a trusted, private hotspot and only for files permitted by your organization's policies.
- The PIN is a basic access check, not enterprise-grade authentication.
- Android hotspot IP/interface behavior differs by device. If the displayed address is unreachable, connect both devices to the same Wi-Fi and retry, or check the phone's hotspot-connected-device details.
- The server is stopped when the app is closed. This first version does not yet run as a persistent foreground service.
- Test with small files first before transferring important or very large files.
