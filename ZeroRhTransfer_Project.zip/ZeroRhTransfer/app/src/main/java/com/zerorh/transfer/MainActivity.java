package com.zerorh.transfer;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.*;
import android.content.Context;
import android.net.wifi.WifiManager;
import android.text.format.Formatter;
import java.net.*;
import java.io.*;
import java.util.*;
import org.nanohttpd.protocols.http.NanoHTTPD;

public class MainActivity extends Activity {
    TransferServer server;
    TextView status, address, pinView;
    Button start, stop;
    String pin;
    File transferDir;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        transferDir = new File(getExternalFilesDir(null), "Received");
        if (!transferDir.exists()) transferDir.mkdirs();
        pin = String.format(Locale.US, "%06d", new Random().nextInt(1000000));
        buildUI();
    }
    void buildUI() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,24,28,24); root.setBackgroundColor(Color.rgb(247,250,252));
        ImageView logo = new ImageView(this); logo.setImageResource(getResources().getIdentifier("tm_logo", "drawable", getPackageName())); logo.setAdjustViewBounds(true); logo.setMaxHeight(240); logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        root.addView(logo, new LinearLayout.LayoutParams(-1, 230));
        TextView title = new TextView(this); title.setText("ZeroRh Transfer"); title.setTextSize(26); title.setTypeface(null, Typeface.BOLD); title.setTextColor(Color.rgb(18,61,90)); title.setGravity(Gravity.CENTER); root.addView(title);
        TextView sub = new TextView(this); sub.setText("Mobile ↔ Laptop • Local Wi-Fi only"); sub.setGravity(Gravity.CENTER); sub.setTextColor(Color.DKGRAY); sub.setPadding(0,4,0,18); root.addView(sub);
        status = new TextView(this); status.setText("● Server stopped"); status.setTextSize(17); status.setTypeface(null, Typeface.BOLD); status.setTextColor(Color.rgb(180,60,60)); status.setGravity(Gravity.CENTER); root.addView(status);
        address = new TextView(this); address.setText("Connection address will appear here"); address.setTextSize(16); address.setGravity(Gravity.CENTER); address.setPadding(0,18,0,4); root.addView(address);
        pinView = new TextView(this); pinView.setText("Transfer PIN: " + pin); pinView.setTextSize(20); pinView.setTypeface(null, Typeface.BOLD); pinView.setTextColor(Color.rgb(18,61,90)); pinView.setGravity(Gravity.CENTER); pinView.setPadding(0,8,0,18); root.addView(pinView);
        start = new Button(this); start.setText("START TRANSFER SERVER"); root.addView(start); stop = new Button(this); stop.setText("STOP SERVER"); root.addView(stop);
        TextView instructions = new TextView(this); instructions.setText("HOW TO CONNECT\n1. Turn ON your phone hotspot.\n2. Connect office laptop to this hotspot.\n3. Tap START TRANSFER SERVER.\n4. Enter the shown address in laptop browser.\n5. Enter the 6-digit PIN on the web page.\n\nReceived files are saved inside this app's Received folder.\nKeep this app open while transferring."); instructions.setTextColor(Color.rgb(50,60,70)); instructions.setTextSize(15); instructions.setPadding(8,20,8,8); root.addView(instructions);
        start.setOnClickListener(v -> startServer()); stop.setOnClickListener(v -> stopServer());
        setContentView(root);
    }
    String getLocalIp() {
        try { Enumeration<NetworkInterface> en=NetworkInterface.getNetworkInterfaces(); while(en.hasMoreElements()){ NetworkInterface ni=en.nextElement(); if(!ni.isUp()||ni.isLoopback()) continue; Enumeration<InetAddress> ae=ni.getInetAddresses(); while(ae.hasMoreElements()){ InetAddress a=ae.nextElement(); if(a instanceof Inet4Address && !a.isLoopbackAddress()) return a.getHostAddress(); } } } catch(Exception ignored){}
        try { WifiManager wm=(WifiManager)getApplicationContext().getSystemService(Context.WIFI_SERVICE); return Formatter.formatIpAddress(wm.getConnectionInfo().getIpAddress()); } catch(Exception e){return "IP unavailable";}
    }
    void startServer() {
        if(server!=null){ Toast.makeText(this,"Server is already running",Toast.LENGTH_SHORT).show(); return; }
        try { server=new TransferServer(8080, transferDir, pin); server.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false); String ip=getLocalIp(); address.setText("Open on laptop:\nhttp://"+ip+":8080"); status.setText("● Server running"); status.setTextColor(Color.rgb(20,150,100)); start.setEnabled(false); Toast.makeText(this,"Server started",Toast.LENGTH_SHORT).show(); }
        catch(Exception e){ server=null; status.setText("Server failed: "+e.getMessage()); Toast.makeText(this,"Could not start server",Toast.LENGTH_LONG).show(); }
    }
    void stopServer(){ if(server!=null){ server.stop(); server=null; } status.setText("● Server stopped"); status.setTextColor(Color.rgb(180,60,60)); address.setText("Connection address will appear here"); start.setEnabled(true); Toast.makeText(this,"Server stopped",Toast.LENGTH_SHORT).show(); }
    @Override protected void onDestroy(){stopServer(); super.onDestroy();}

    static class TransferServer extends NanoHTTPD {
        final File dir; final String pin;
        TransferServer(int port, File dir, String pin){ super(port); this.dir=dir; this.pin=pin; }
        @Override public Response serve(IHTTPSession s){
            try {
                String uri=s.getUri(); Map<String,String> p=s.getParms();
                if(uri.equals("/") || uri.equals("/index.html")) return newFixedLengthResponse(Response.Status.OK,"text/html; charset=utf-8",page());
                if(!pin.equals(p.get("pin"))) return newFixedLengthResponse(Response.Status.UNAUTHORIZED,"text/plain","PIN required or incorrect");
                if(uri.equals("/list")){ StringBuilder b=new StringBuilder("["); File[] fs=dir.listFiles(); if(fs!=null){ for(File f:fs){ if(!f.isFile())continue; if(b.length()>1)b.append(','); b.append("{\"name\":\"").append(json(f.getName())).append("\",\"size\":\").append(f.length()).append("}"); }} b.append(']'); return newFixedLengthResponse(Response.Status.OK,"application/json",b.toString()); }
                if(uri.equals("/download")){ String name=p.get("name"); File f=safeFile(name); if(f==null||!f.exists())return newFixedLengthResponse(Response.Status.NOT_FOUND,"text/plain","Not found"); FileInputStream in=new FileInputStream(f); Response r=newChunkedResponse(Response.Status.OK,mime(f.getName()),in); r.addHeader("Content-Disposition","attachment; filename=\""+f.getName().replace("\"","")+"\""); return r; }
                if(uri.equals("/upload") && s.getMethod()==Method.POST){ Map<String,String> files=new HashMap<>(); s.parseBody(files); String temp=files.get("file"); if(temp==null) temp=files.values().stream().findFirst().orElse(null); if(temp==null)return newFixedLengthResponse(Response.Status.BAD_REQUEST,"text/plain","No file received"); String name=p.get("filename"); if(name==null||name.trim().isEmpty())name="upload.bin"; name=name.replaceAll("[/\\\\]","_"); File target=unique(new File(dir,name)); try(InputStream in=new FileInputStream(temp); OutputStream out=new FileOutputStream(target)){byte[] buf=new byte[65536]; int n; while((n=in.read(buf))>0)out.write(buf,0,n);} return newFixedLengthResponse(Response.Status.OK,"application/json","{\"ok\":true,\"name\":\""+json(target.getName())+"\",\"size\":\""+target.length()+"\"}"); }
                if(uri.equals("/delete")){ File f=safeFile(p.get("name")); if(f!=null&&f.exists()&&f.delete())return newFixedLengthResponse(Response.Status.OK,"text/plain","Deleted"); return newFixedLengthResponse(Response.Status.BAD_REQUEST,"text/plain","Unable to delete"); }
                return newFixedLengthResponse(Response.Status.NOT_FOUND,"text/plain","Not found");
            } catch(Exception e){ return newFixedLengthResponse(Response.Status.INTERNAL_ERROR,"text/plain","Transfer error: "+e.getMessage()); }
        }
        File safeFile(String name){ if(name==null)return null; File f=new File(dir,name); try{ if(!f.getCanonicalPath().startsWith(dir.getCanonicalPath()+File.separator))return null; }catch(Exception e){return null;} return f; }
        File unique(File f){ if(!f.exists())return f; String n=f.getName(), base=n, ext=""; int i=n.lastIndexOf('.'); if(i>0){base=n.substring(0,i);ext=n.substring(i);} int x=1; while(new File(dir,base+" ("+x+")"+ext).exists())x++; return new File(dir,base+" ("+x+")"+ext); }
        static String json(String x){return x.replace("\\","\\\\").replace("\"","\\\"").replace("\n"," ").replace("\r"," ");}
        static String mime(String n){String x=n.toLowerCase(); if(x.endsWith(".pdf"))return "application/pdf";if(x.endsWith(".jpg")||x.endsWith(".jpeg"))return "image/jpeg";if(x.endsWith(".png"))return "image/png";if(x.endsWith(".xlsx"))return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";if(x.endsWith(".docx"))return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";if(x.endsWith(".zip"))return "application/zip";return "application/octet-stream";}
        String page(){return """
<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><title>ZeroRh Transfer</title><style>body{font-family:Arial;background:#f4f7fa;color:#123d5a;margin:0;padding:20px}main{max-width:900px;margin:auto;background:white;padding:22px;border-radius:18px;box-shadow:0 4px 20px #0001}h1{margin-top:0}.box{border:2px dashed #9ab3c4;border-radius:14px;padding:24px;text-align:center;margin:14px 0}button{background:#159b74;color:white;border:0;border-radius:8px;padding:10px 14px;cursor:pointer;margin:4px}input{padding:10px;border:1px solid #ccd8df;border-radius:8px}table{width:100%;border-collapse:collapse}td,th{padding:10px;border-bottom:1px solid #eee;text-align:left;word-break:break-word}.muted{color:#687783}.progress{height:8px;background:#e6edf2;border-radius:8px;overflow:hidden}.bar{height:100%;background:#159b74;width:0}#msg{font-weight:bold}</style></head><body><main><h1>ZeroRh Transfer</h1><p>Local transfer between this laptop and your Android phone.</p><div id='login'><label>Enter 6-digit PIN: <input id='pin' type='password' maxlength='6'></label><button onclick='connect()'>Connect</button></div><section id='app' style='display:none'><div class='box'><input id='files' type='file' multiple><button onclick='upload()'>Send files to mobile</button><div class='progress'><div class='bar' id='bar'></div></div><p id='msg'></p></div><h2>Files on phone</h2><button onclick='refresh()'>Refresh</button><table><thead><tr><th>File</th><th>Size</th><th>Action</th></tr></thead><tbody id='rows'></tbody></table><h2>Text transfer</h2><textarea id='txt' style='width:100%;height:100px'></textarea><button onclick='copyText()'>Copy text</button></section></main><script>let P='';function connect(){P=document.getElementById('pin').value;if(P.length!==6){alert('Enter 6-digit PIN');return}fetch('/list?pin='+P).then(r=>{if(!r.ok)throw 0;document.getElementById('login').style.display='none';document.getElementById('app').style.display='block';refresh()}).catch(()=>alert('Wrong PIN or connection error'))}function refresh(){fetch('/list?pin='+P).then(r=>r.json()).then(a=>{document.getElementById('rows').innerHTML=a.map(f=>`<tr><td>${esc(f.name)}<br><small>${size(f.size)}</small></td><td>${size(f.size)}</td><td><a href='/download?pin=${P}&name=${encodeURIComponent(f.name)}'>Download</a> <button onclick='del(${JSON.stringify(f.name)})'>Delete</button></td></tr>`).join('')})}function upload(){let fs=document.getElementById('files').files;if(!fs.length)return alert('Choose files first');let done=0;document.getElementById('msg').textContent='Uploading…';Array.from(fs).forEach(f=>{let fd=new FormData();fd.append('file',f);fd.append('filename',f.name);fd.append('pin',P);let x=new XMLHttpRequest();x.open('POST','/upload?pin='+P+'&filename='+encodeURIComponent(f.name));x.upload.onprogress=e=>{if(e.lengthComputable)document.getElementById('bar').style.width=Math.round(e.loaded/e.total*100)+'%'};x.onload=()=>{done++;if(done===fs.length){document.getElementById('msg').textContent='Upload complete';refresh()}};x.onerror=()=>document.getElementById('msg').textContent='Upload failed';x.send(fd)})}function del(n){if(confirm('Delete '+n+'?'))fetch('/delete?pin='+P+'&name='+encodeURIComponent(n)).then(refresh)}function copyText(){navigator.clipboard.writeText(document.getElementById('txt').value).then(()=>alert('Copied'))}function esc(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}function size(n){if(n<1024)return n+' B';if(n<1048576)return (n/1024).toFixed(1)+' KB';return (n/1048576).toFixed(1)+' MB'}</script></body></html>
"""; }
    }
}
